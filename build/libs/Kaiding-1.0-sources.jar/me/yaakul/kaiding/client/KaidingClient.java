package me.yaakul.kaiding.client;

import com.mojang.brigadier.Command;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.ClientCommands;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;

import java.awt.*;

public class KaidingClient implements ClientModInitializer {

    public static final String MOD_ID = "kaiding";

    @Override
    public void onInitializeClient() {
        ConfigManager.load();
        KaidingCommand.register();
        MenuOpener.init();
        KaidingKeybinds.init();
        Logic.init();

        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> ConfigManager.save());
    }
}
